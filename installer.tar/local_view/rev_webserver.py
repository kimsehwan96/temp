from threading import Lock
from flask import Flask, render_template
from flask_socketio import SocketIO, emit
from flask_cors import CORS
from util import get_profile, get_sensor_names
from revpi import RevolutionPi
import os
import traceback

async_mode = None  # for buffer flushing
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, async_mode=async_mode, cors_allowed_origins='*',
                    port=8888)  # use as same port number as barrel
thread = None
thread_lock = Lock()
CORS(app)
TEST_VALUE = None
revpi = RevolutionPi()
DIR = os.path.dirname(os.path.abspath('__file__'))
CONF_PATH = DIR + '/config.json'


def handler(event, context):
    pass


@app.route('/')
def index():
    return render_template('index.html')


@socketio.on('request', namespace='/data')
def push_values(msg):
    revpi.data_normalization()
    emit('rtdata', {'data': revpi.after_buffer})
    # print("number of thread : ", threading.active_count())


@socketio.on('sensor_name', namespace='/profile')
def push_profile(msg):
    try:
        sensor_profile = get_sensor_names(CONF_PATH)
    except Exception as e:
        print("error occured when emmiting sensor profile :", traceback.format_exc())
    emit('sensor_name', {'name': sensor_profile})


if __name__ == '__main__':
    socketio.run(app, debug=True, port=8888)
else:
    socketio.run(app, debug=True, port=8888)
