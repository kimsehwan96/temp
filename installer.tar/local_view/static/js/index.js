'use strict';

const binder = io("http://localhost:8888/data");

setInterval(() => {
    binder.emit('request', {'time': Date.now()});
}, 1000);

setInterval(() => {
    binder.on('rtdata', (data) => {
        console.log('binder buffered: ', data)
        const target = document.getElementById('data_1')
        const target_2 = document.getElementById('data_2')
        const target_3 = document.getElementById('data_3')
        const target_4 = document.getElementById('data_4')
        console.log(target)
        target.innerHTML = data.data[0] + '\nmmAQ'
        target_2.innerHTML = data.data[1] + '\nA'
        target_3.innerHTML = data.data[2] + '\nA'
        target_4.innerHTML = data.data[3] + '\n℃'
    });
}, 1000);

const profiler = io("http://localhost:8888/profile");

profiler.emit('sensor_name', {'null': 'None'});

const get_profile = () => {
    profiler.on('sensor_name', function (profile) {
        console.log('get_data', profile)
        const sensor_name = document.getElementById('sensor_name')
        const sensor_name_2 = document.getElementById('sensor_name_2')
        const sensor_name_3 = document.getElementById('sensor_name_3')
        const sensor_name_4 = document.getElementById('sensor_name_4')
        console.log(profile)
        sensor_name.innerHTML = profile.name[0]
        sensor_name_2.innerHTML = profile.name[1]
        sensor_name_3.innerHTML = profile.name[2]
        sensor_name_4.innerHTML = profile.name[3]
    })
}

get_profile();
