# 도장부스 로컬뷰 자동 인스톨러 스크립트.

Revpi의 Pictory는 Revpi 하드웨어 관련 내용을 설정할 수 있도록 웹 인터페이스로 제공해준다.

이 Pictory의 설정파일은 Revpi 내의 `/var/www/pictory/projects` 에 `_config.rsc` 파일로 저장된다.

따라서 Pictory를 사용자가 일일이 수정하지 않아도 해당 내용만 수정하면 되기 때문에 이 내용을 스크립트에 반영 함

`autostart` 파일의 경우 라즈베리파이 부팅 이후 자동으로 시작될 프로세스들을 정의하는 파일임

`localview.service`의 경우 로컬뷰를 `systemd`를 이용하여 자동으로 실행하도록 정의하는 내용임.

`local_view` 디렉터리 내 웹 코드의 경우 향후 수정 가능 (w/홍경원)

