#!/bin/bash

#update package manager

sudo apt-get -y update
sudo apt-get -y upgrade

#setup pictory

sudo cp _config.rsc /var/www/pictory/projects

# check piTest
sudo piTest -x

# install chrome and etc..
sudo apt-get install -y chromium-browser ibus-hangul fonts-unfonts-core

if [ $? -ne 0 ]; then
  echo "installing chrome failed"
  exit 1
else
  echo "installing chrome success"
fi

/usr/bin/python3 -m pip install -r requirements.txt

if [ $? -ne 0 ]; then
  echo "installing python requirements failed"
  exit 1
else
  echo "installing python requirements success"
fi

#setting up local view..
echo "setup localview"

sudo mkdir /root/local_view
sudo cp -r local_view /root/
sudo cp localview.service /etc/systemd/system/
sudo systemctl enable localview
sudo systemctl start localview
sudo cp -f autostart /etc/xdg/lxsession/LXDE-pi/autostart

#monitor configuration
echo "setup monitor"

echo "max_usb_current=1" >> /boot/config.txt
echo "hdmi_group=2" >> /boot/config.txt
echo "hdmi_mode=87" >> /boot/config.txt
echo "hdmi_cvt 800 480 60 6 0 0 0" >> /boot/config.txt
echo "hdmi_drive=1" >> /boot/config.txt
